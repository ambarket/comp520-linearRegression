package linearRegressor;

public class LearningCurveEntry {
			public int numberOfTrainingExamples;
			public double trainingError;
			public double validationError;
			public double testError;
}
